﻿namespace WebApplication2.Models
{
    public class Traffic_Violation
    {
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set;}
    }
}
