﻿namespace WebApplication2.Models
{
    public class join2
    {
        public Customer Customer { get; set; }
        public List<Vehicle> Vehicles { get; set; } 
        public List<Violation> Violations { get; set; }
    }
}
