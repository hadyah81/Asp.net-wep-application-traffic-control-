﻿namespace WebApplication2.Models
{
    public class join1
    {
        public Customer customer { get; set; }
        public Violation violation { get; set; }
        public Vehicle vehicle { get; set; }
    }
}
