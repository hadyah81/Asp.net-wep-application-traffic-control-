﻿namespace WebApplication2.Models
{
    public class Email
    {
        public String TO { get; set; }
        public String Subject { get; set; }
        public String Body { get; set; }
        
        public String Gmail { get; set; }
        public String password { get; set; }
    }
}
