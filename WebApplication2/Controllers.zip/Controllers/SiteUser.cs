﻿namespace WebApplication2.Controllers
{
    public class SiteUser
    {
        public string? Email { get; internal set; }
    }
}